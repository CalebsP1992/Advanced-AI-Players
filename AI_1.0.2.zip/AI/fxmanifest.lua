fx_version 'cerulean'
game 'gta5'

author 'PlayDough - SBB City'
description 'Advanced AI Players'
version '1.0.2'

client_scripts {
    'script.lua'
}

server_scripts {
    'server.lua'
}